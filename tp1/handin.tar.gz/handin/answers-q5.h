/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * Copyright (C) 2019 Olivier Dion <olivier.dion@polymtl.ca>
 *
 * Init Lab - answers-q5.h
 */


#ifndef _ANSWERS_Q5_H
#define _ANSWERS_Q5_H


// Report here the answer for question 5. a)
char Q5_ANS_A[] = "/tmp/filewriter_secret_5b72ce3f76507e97";

// Report here the answer for question 5. b)
char Q5_ANS_B[] = "/tmp/filewriter_secret_child_b1e6323f3c32e734";

// Report here the answer for question 5. c)
char Q5_ANS_C[] = "3cfedd662092830ac8da58d3851ba4ec6d41f4f9ee752dacd096068cf875cf2e";

// Report here the answer for question 5. d)
char Q5_ANS_D[] = "fputs";

// Report here the answer for question 5. e)
char Q5_ANS_E[] = "PROCSLEEP";

#endif
