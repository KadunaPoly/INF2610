/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * Copyright (C) 2019 Olivier Dion <olivier.dion@polymtl.ca>
 *
 * memsim.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>


#include "memsim.h"
#include "memsim/libmemsim.h"
#include "libmemlab.h"


#define PAGE_BITS 11
#define PAGE_SIZE (1 << PAGE_BITS)
#define MAX_PAGE 128
#define TLB_ENTRIES 16
#define FRAME_COUNT 49
#define FRAME_OFFSET 567
#define MIN_PHYS_ADDR 0x11b800
#define MAX_PHYS_ADDR 0x133fff

typedef unsigned long ulong;


/*
 * Calcule et renvoie le déplacement dans la page correspondant à l'adresse
 * fournie en argument.
 */
unsigned long getPageOffset(unsigned long addr)
{
	return addr & (PAGE_SIZE - 1);
}

/*
 * Calcule et renvoie le numéro de page correspondant à l'adresse virtuelle
 * fournie en argument.
 */
unsigned long getPageNumber(unsigned long addr)
{
	return addr >> PAGE_BITS;
}

/*
 * Calcule et renvoie l'adresse de début de page (ou cadre) correspondant au
 * numéro de page (ou de cadre) fourni en argument.
 */
unsigned long getStartPageAddress(unsigned long pageNumber)
{
	return pageNumber << PAGE_BITS;
}

/*
 * Initialise votre structure permettant de stocker l'état de la mémoire
 *
 * Retourne:
 * - un pointeur vers une structure initialisée stockant l'état de la mémoire
 */
struct paging_system_state *initMemoryState() {
	struct paging_system_state *state = malloc(sizeof(struct paging_system_state));

	/* TLB */
	state->tlb = malloc(sizeof(struct tlb));
#define ALLOC(name) state->tlb-> name = calloc(TLB_ENTRIES, sizeof(*(state->tlb-> name)))
	ALLOC(pageNumbers);
	ALLOC(frameNumbers);
	ALLOC(lastAccessTimestamps);
	ALLOC(entryCreationTimestamps);
	ALLOC(isUsed);
#undef ALLOC

	/* Page table */
	state->pt = malloc(sizeof(struct pt));
#define ALLOC(name) state->pt-> name = calloc(MAX_PAGE, sizeof(*(state->pt-> name)))
	ALLOC(frameNumbers);
	ALLOC(isValid);
#undef ALLOC

	/* Memory */
	state->mem = malloc(sizeof(struct memory));
#define ALLOC(name) state->mem-> name = calloc(FRAME_COUNT, sizeof(*(state->mem-> name)))
	ALLOC(pageNumbers);
	ALLOC(lastAccessTimestamps);
	ALLOC(entryCreationTimestamps);
	ALLOC(isUsed);
#undef ALLOC

	return state;
}

/*
 * Cherche la traduction de l'adresse virtuelle dans le TLB.
 *
 * Si la traduction est trouvée dans le TLB, modifier les champs:
 * - mr->wasFoundInTLB
 * - mr->physicalAddress
 *
 * Vous devez également mettre à jour les timestamps dans le TLB et la table
 * de pages.
 */
void lookupInTLB(struct paging_system_state *ms,
                 struct memory_request *mr)
{
	ulong offset = getPageOffset(mr->virtualAddr);
	ulong page = getPageNumber(mr->virtualAddr);
	int found = 0;
	for (int i=0; i<TLB_ENTRIES; ++i) {
		if (ms->tlb->isUsed[i] && page == ms->tlb->pageNumbers[i]) {
			mr->physicalAddr = getStartPageAddress(ms->tlb->frameNumbers[i]) | offset;
			ms->tlb->lastAccessTimestamps[i] = mr->timestamp;
			ms->mem->lastAccessTimestamps[ms->pt->frameNumbers[page] - FRAME_OFFSET] = mr->timestamp;
			found = 1;
			break;
 		}
	}
	mr->wasFoundInTLB = found;
}

/*
 * Cherche la traduction de l'adresse virtuelle dans la table de pages.
 *
 * Si la traduction est trouvée dans la table de pages, modifier le champ:
 * - mr->physicalAddress
 *
 * Sinon, modifier le champ:
 * - mr->wasPageFault
 *
 * Vous devez également mettre à jour les timestamps dans la mémoire centrale.
 */
void lookupInPT(struct paging_system_state *ms,
                struct memory_request *mr)
{
	ulong offset = getPageOffset(mr->virtualAddr);
	ulong page = getPageNumber(mr->virtualAddr);
	if (ms->pt->isValid[page]) {
		mr->physicalAddr = getStartPageAddress(ms->pt->frameNumbers[page]) | offset;
		ms->mem->lastAccessTimestamps[ms->pt->frameNumbers[page] - FRAME_OFFSET] = mr->timestamp;
		return;
	}
	mr-> wasPageFault = 1;
}

/*
 * Ajoute la traduction de l'adresse virtuelle dans le TLB.
 *
 * Si le TLB est plein, vous devez prendre en compte la politique de
 * remplacement du TLB pour modifier les champs:
 * - mr->wasEvictionInTLB
 * - mr->virtualAddrEvictedFromTLB
 *
 * N'oubliez pas d'initialiser correctement le timestamp de votre nouvelle
 * entrée dans le TLB.
 *
 * Attention: Si une page X est retirée de la mémoire où elle est remplacée par
 * une page Y, alors le TLB est mis à jour pour remplacer X par Y.
 */
void addToTLB(struct paging_system_state *ms,
              struct memory_request *mr)
{
	ulong offset = getPageOffset(mr->virtualAddr);
	ulong page = getPageNumber(mr->virtualAddr);
	int lru = 0;
	int empty = TLB_ENTRIES;
	int candidate;

	for (int i=0; i<TLB_ENTRIES; ++i) {
		if (ms->tlb->isUsed[i]) {
			if (ms->tlb->pageNumbers[i] == page) {
				candidate = i;
				goto no_eviction;
			}
			if (ms->tlb->lastAccessTimestamps[i] < ms->tlb->lastAccessTimestamps[lru]) {
				lru = i;
			}
		}
		/* Entry not used */
		else if (i < empty){
			empty = i;
		}
	}

	/* Entry not used found */
	if (empty < TLB_ENTRIES) {
		candidate = empty;
		ms->tlb->isUsed[empty] = 1;
	}
	/* Eviction of LRU */
	else {
		candidate = lru;
		mr->wasEvictionInTLB = 1;
		mr->virtualAddrEvictedFromTLB = getStartPageAddress(ms->tlb->pageNumbers[lru]);
	}
	/* Set new page number */
	ms->tlb->pageNumbers[candidate] = page;
	ms->tlb->entryCreationTimestamps[candidate] = mr->timestamp;
no_eviction:
	ms->tlb->frameNumbers[candidate] = getPageNumber(mr->physicalAddr);
	ms->tlb->lastAccessTimestamps[candidate] = mr->timestamp;
}

/*
 * Si cette fonction est appelée en dernier recours, cela signifie que la page
 * demandée n'est même pas présente en mémoire. Il faut donc l'amener en
 * mémoire puis ajouter la traduction dans la table de pages.
 *
 * Si la mémoire est pleine, vous devez prendre en compte la politique de
 * remplacement de la mémoire pour modifier les champs:
 * - mr->wasEvictionInMemory
 * - mr->virtualAddrEvictedFromMemory
 *
 * Dans tous les cas, vous devez modifier le champ:
 * - mr->physicalAddress
 */
void getPageIntoMemory(struct paging_system_state *ms,
                       struct memory_request *mr)
{
	ulong offset = getPageOffset(mr->virtualAddr);
	ulong page = getPageNumber(mr->virtualAddr);

	int eviction = 0;
	int candidate;
	for (int i=0; i<FRAME_COUNT; ++i) {
		if (!ms->mem->isUsed[i]) {
			candidate = i;
			goto no_eviction;
		}
		if (ms->mem->entryCreationTimestamps[i] < ms->mem->entryCreationTimestamps[eviction])
			eviction = i;
	}
	/* Memory request eviction */
	mr->wasEvictionInMemory = 1;
	mr->virtualAddrEvictedFromMemory = getStartPageAddress(ms->mem->pageNumbers[eviction]);

	/* Trash page table */
	ms->pt->isValid[ms->mem->pageNumbers[eviction]] = 0;

	candidate = eviction;
no_eviction:
	/* Update memory */
	ms->mem->pageNumbers[candidate] = page;
	ms->mem->lastAccessTimestamps[candidate] = mr->timestamp;
	ms->mem->entryCreationTimestamps[candidate] = mr->timestamp;
	ms->mem->isUsed[candidate] = 1;

	/* Update page table */
	ms->pt->frameNumbers[page] = candidate + FRAME_OFFSET;
	ms->pt->isValid[page] = 1;

	/* Get physical addr */
	mr->physicalAddr = getStartPageAddress(candidate + FRAME_OFFSET) | offset;
}

/*
 * Traite une demande d'accès à la mémoire.
 *
 * Cette fonction mute les structures fournies en arguments pour modifier
 * l'état de la mémoire et donner des informations sur la demande d'accès en
 * argument (traduction en adresse physique, présence ou non de défaut de page,
 * présence ou non de la traduction dans le TLB...)
 *
 * Arguments:
 * - un pointeur vers votre structure représentant l'état de la mémoire
 * - un pointeur vers une structure représentant la demande d'accès
 */
void processMemoryRequest(struct paging_system_state *ms,
                          struct memory_request *mr) {
	lookupInTLB(ms, mr);
	if (mr->wasFoundInTLB == 1)
	{
		return;
	}
	/* Lookup in page table */
	lookupInPT(ms, mr);
	if (mr->wasPageFault == 0)
	{
		addToTLB(ms, mr);
		return;
	}
	/* Get frame in memory */
	getPageIntoMemory(ms, mr);
	addToTLB(ms, mr);
}

/*
 * Désalloue votre structure permettant de stocker l'état de la mémoire
 *
 * Arguments:
 * - un pointeur vers votre structure stockant l'état de la mémoire
 */
void cleanMemoryState(struct paging_system_state *ms)
{
#define FREE(name) free(ms->tlb-> name)
	FREE(pageNumbers);
	FREE(frameNumbers);
	FREE(lastAccessTimestamps);
	FREE(entryCreationTimestamps);
	FREE(isUsed);
#undef FREE
#define FREE(name) free(ms->pt-> name)
	FREE(frameNumbers);
	FREE(isValid);
#undef FREE
#define FREE(name) free(ms->mem-> name)
	FREE(pageNumbers);
	FREE(lastAccessTimestamps);
	FREE(entryCreationTimestamps);
	FREE(isUsed);
#undef FREE
}
